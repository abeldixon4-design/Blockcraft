/* Blockcraft service worker: makes the app start instantly and run with no connection. */
const CACHE = "blockcraft-v1";
const CORE = [
  "./", "./index.html", "./manifest.webmanifest",
  "./icons/icon-192.png", "./icons/icon-512.png",
  "./icons/icon-maskable-512.png", "./icons/apple-touch-icon.png"
];
const THREE_URL = "https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js";

self.addEventListener("install", function(e){
  e.waitUntil((async function(){
    const c = await caches.open(CACHE);
    await c.addAll(CORE);
    // three.js lives on a CDN, so grab it opaquely for offline starts
    try{ await c.add(new Request(THREE_URL, {mode: "no-cors"})); }catch(err){}
    self.skipWaiting();
  })());
});

self.addEventListener("activate", function(e){
  e.waitUntil((async function(){
    const keys = await caches.keys();
    await Promise.all(keys.filter(function(k){ return k !== CACHE; })
                          .map(function(k){ return caches.delete(k); }));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", function(e){
  if(e.request.method !== "GET") return;
  e.respondWith((async function(){
    const hit = await caches.match(e.request);
    if(hit) return hit;
    try{
      const res = await fetch(e.request);
      if(res && (res.ok || res.type === "opaque")){
        const c = await caches.open(CACHE);
        c.put(e.request, res.clone());
      }
      return res;
    }catch(err){
      const shell = await caches.match("./index.html");
      if(shell) return shell;
      return new Response("Offline", {status: 503});
    }
  })());
});
