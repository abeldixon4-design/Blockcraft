# Blockcraft

A voxel survival game that installs to your home screen and runs with no connection.

## Files

    index.html              the whole game
    manifest.webmanifest    name, icons, launch behaviour
    sw.js                   offline cache
    icons/                  app icons, drawn from the game's own block textures

## Putting it online

A service worker only runs over **https** (or `http://localhost`), so the app has to be
served rather than opened from your files. Any of these work:

**GitHub Pages** — make a repo, drop these files in the root, push, then turn on Pages
in Settings. Your app lives at `https://<you>.github.io/<repo>/`.

**Netlify Drop** — go to app.netlify.com/drop and drag the whole folder onto the page.
You get a URL in a few seconds, no account needed.

**Your own machine** — from inside this folder:

    python3 -m http.server 8000

then open `http://localhost:8000`. Service workers are allowed on localhost.

## Installing it

**Android / Chrome / Edge** — an **Install App** button appears on the title screen.
Tap it. You can also use the browser menu's Install option.

**iPhone / iPad** — Safari has no install prompt. Tap Share, then **Add to Home Screen**.
The title screen reminds you.

**Desktop** — an install icon shows up in the address bar.

Once installed it opens fullscreen with no browser chrome, keeps the screen awake while
you play, and pauses and saves itself if you switch away.

## Saved worlds

Inside Claude the game uses the built-in artifact storage. Anywhere else it uses the
browser's local storage, and asks the browser to mark it persistent so it will not be
cleared to reclaim space. Worlds are stored as a seed plus the blocks you changed, so
they stay small.

Clearing the site's data in your browser deletes your worlds. There is no cloud copy.

## Offline

The first load needs a connection: three.js comes from a CDN. The service worker caches
it along with the game, so after that it starts with no network at all.

## Changing it

Everything is in `index.html` — no build step, no dependencies beyond three.js.
Bump `CACHE` in `sw.js` whenever you edit the game, or installed copies will keep
serving the old version.
